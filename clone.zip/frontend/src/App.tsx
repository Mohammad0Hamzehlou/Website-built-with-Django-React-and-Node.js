// frontend/src/App.tsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import MovieDetail from './MovieDetail';

interface Genre {
    id: number;
    name: string;
}

interface Movie {
    id: number;
    title: string;
    description: string;
    release_date: string;
    genres: Genre[];
    created_at: string;
    thumbnail?: string | null;
}

const App: React.FC = () => {
    const [searchQuery, setSearchQuery] = useState<string>('');
    const [featuredMovie, setFeaturedMovie] = useState<Movie | null>(null);
    const [movies, setMovies] = useState<Movie[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchMovies = async () => {
            try {
                setLoading(true);
                setError(null);
                console.log('Fetching movies from API...');
                const response = await fetch('http://localhost:8000/api/posts/movies/', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
                console.log('Response status:', response.status);
                if (!response.ok) throw new Error(`Failed to fetch movies: ${response.statusText}`);
                const data: Movie[] = await response.json();
                console.log('Fetched data:', data);

                if (data.length === 0) {
                    setError('No movies found in the database.');
                }

                const moviesWithThumbnails = data.map(movie => ({
                    ...movie,
                    thumbnail: movie.thumbnail || `https://picsum.photos/300/169?random=${movie.id}`
                }));

                setMovies(moviesWithThumbnails);
                if (moviesWithThumbnails.length > 0) setFeaturedMovie(moviesWithThumbnails[0]);
            } catch (error: any) {
                console.error('Error fetching movies:', error);
                setError(error.message);
                setFeaturedMovie({
                    id: 1,
                    title: 'The Epic Adventure',
                    description: 'لورم ایپسوم متن ساختگی...',
                    release_date: '2023-01-01',
                    genres: [],
                    created_at: '2023-01-01T12:00:00Z',
                    thumbnail: 'https://picsum.photos/1200/600?random=1',
                });
                setMovies([
                    { id: 2, title: 'Movie 1', description: '', release_date: '2023-01-01', genres: [], created_at: '2023-01-01T12:00:00Z', thumbnail: 'https://picsum.photos/300/169?random=2' },
                    { id: 3, title: 'Movie 2', description: '', release_date: '2023-01-01', genres: [], created_at: '2023-01-01T12:00:00Z', thumbnail: 'https://picsum.photos/300/169?random=3' },
                ]);
            } finally {
                setLoading(false);
            }
        };

        fetchMovies();
    }, []);

    const filteredMovies = movies.filter((movie) =>
        movie.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const movieCategories: { [key: string]: Movie[] } = {
        'Trending Now': filteredMovies.slice(0, 4),
        'Popular': filteredMovies.slice(4),
    };

    return (
        <Router>
            <div className="app">
                <style>{`
                    @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');

                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                    }

                    body {
                        font-family: 'Roboto', sans-serif;
                        background-color: #0D0D0D;
                        color: #B0B7C0;
                    }

                    .app {
                        min-height: 100vh;
                        width: 100vw; /* مطمئن می‌شیم که کل عرض صفحه رو بگیره */
                        overflow-x: hidden; /* از اسکرول افقی ناخواسته جلوگیری می‌کنیم */
                    }

                    .loading, .error {
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        font-size: 24px;
                        color: #B0B7C0;
                    }

                    .error {
                        color: #ff5555;
                    }

                    .header {
                        position: fixed;
                        top: 0;
                        left: 0;
                        right: 0;
                        display: flex;
                        align-items: center;
                        padding: 15px 40px;
                        background: rgba(26, 42, 68, 0.9);
                        backdrop-filter: blur(10px);
                        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
                        z-index: 100;
                        transition: background 0.3s ease;
                    }

                    .header:hover {
                        background: rgba(26, 42, 68, 1);
                    }

                    .logo {
                        font-size: 30px;
                        font-weight: 700;
                        color: #ffffff;
                        margin-right: 60px;
                        text-transform: uppercase;
                        letter-spacing: 2px;
                        background: linear-gradient(90deg, #B0B7C0, #ffffff);
                        -webkit-background-clip: text;
                        -webkit-text-fill-color: transparent;
                    }

                    .nav {
                        display: flex;
                        align-items: center;
                    }

                    .nav a {
                        color: #B0B7C0;
                        text-decoration: none;
                        margin-right: 30px;
                        font-size: 16px;
                        font-weight: 500;
                        position: relative;
                        transition: color 0.3s ease;
                    }

                    .nav a:hover {
                        color: #ffffff;
                    }

                    .nav a::after {
                        content: '';
                        position: absolute;
                        width: 0;
                        height: 2px;
                        bottom: -5px;
                        left: 0;
                        background-color: #ffffff;
                        transition: width 0.3s ease;
                    }

                    .nav a:hover::after {
                        width: 100%;
                    }

                    .search-bar {
                        margin-left: auto;
                        padding: 10px 20px;
                        border: none;
                        border-radius: 25px;
                        background: rgba(13, 13, 13, 0.8);
                        color: #B0B7C0;
                        width: 300px;
                        font-size: 14px;
                        transition: background 0.3s ease, box-shadow 0.3s ease;
                    }

                    .search-bar:focus {
                        outline: none;
                        background: rgba(42, 59, 90, 0.8);
                        box-shadow: 0 0 10px rgba(42, 59, 90, 0.5);
                    }

                    .hero {
                        height: 80vh;
                        width: 100vw; /* عرض کامل صفحه */
                        background-size: cover;
                        background-position: center;
                        position: relative;
                        display: flex;
                        align-items: flex-end;
                        margin: 0; /* حذف margin */
                        padding: 0; /* حذف padding */
                        overflow: hidden;
                    }

                    .hero::before {
                        content: '';
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(0, 0, 0, 0.5);
                        z-index: 1;
                    }

                    .hero-content {
                        position: relative;
                        z-index: 2;
                        padding: 60px;
                        background: linear-gradient(to top, rgba(13, 13, 13, 0.95), transparent);
                        width: 100%;
                        animation: fadeIn 1s ease-in-out;
                    }

                    @keyframes fadeIn {
                        from {
                            opacity: 0;
                            transform: translateY(20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }

                    .hero h1 {
                        font-size: 60px;
                        font-weight: 700;
                        margin-bottom: 20px;
                        color: #ffffff;
                        text-shadow: 3px 3px 8px rgba(0, 0, 0, 0.7);
                    }

                    .hero p {
                        font-size: 20px;
                        font-weight: 300;
                        max-width: 700px;
                        margin-bottom: 30px;
                        line-height: 1.8;
                    }

                    .hero-buttons {
                        display: flex;
                        gap: 20px;
                    }

                    .hero-buttons a {
                        text-decoration: none;
                    }

                    .hero-buttons button {
                        padding: 14px 35px;
                        border: none;
                        border-radius: 30px;
                        font-size: 16px;
                        font-weight: 500;
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        transition: transform 0.2s ease, box-shadow 0.3s ease, background 0.3s ease;
                    }

                    .hero-buttons button:hover {
                        transform: translateY(-3px);
                        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5);
                    }

                    .play-btn {
                        background: #B0B7C0;
                        color: #0D0D0D;
                    }

                    .play-btn:hover {
                        background: #ffffff;
                    }

                    .info-btn {
                        background: #2A3B5A;
                        color: #B0B7C0;
                    }

                    .info-btn:hover {
                        background: #3A4B7A;
                    }

                    .play-icon, .info-icon {
                        font-size: 20px;
                    }

                    .content {
                        padding: 40px 60px;
                        margin-top: -120px;
                    }

                    .category-section {
                        margin-bottom: 50px;
                    }

                    .category-section h2 {
                        font-size: 28px;
                        font-weight: 500;
                        margin-bottom: 20px;
                        color: #ffffff;
                        text-transform: uppercase;
                        letter-spacing: 1.5px;
                        position: relative;
                        padding-left: 20px;
                    }

                    .category-section h2::before {
                        content: '';
                        position: absolute;
                        left: 0;
                        top: 50%;
                        transform: translateY(-50%);
                        width: 5px;
                        height: 30px;
                        background: #B0B7C0;
                    }

                    .movie-list {
                        display: flex;
                        overflow-x: auto;
                        gap: 20px;
                        padding-bottom: 20px;
                        scroll-behavior: smooth;
                    }

                    .movie-card {
                        flex: 0 0 auto;
                        width: 280px;
                        position: relative;
                        transition: transform 0.3s ease, box-shadow 0.3s ease;
                        border-radius: 12px;
                        overflow: hidden;
                        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4);
                        cursor: pointer;
                    }

                    .movie-card:hover {
                        transform: scale(1.05);
                        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
                    }

                    .movie-card img {
                        width: 100%;
                        height: 400px;
                        object-fit: cover;
                        border-radius: 12px;
                        transition: opacity 0.3s ease;
                    }

                    .movie-card:hover img {
                        opacity: 0.8;
                    }

                    .movie-title {
                        position: absolute;
                        bottom: 15px;
                        left: 15px;
                        font-size: 18px;
                        font-weight: 500;
                        background: rgba(26, 42, 68, 0.85);
                        padding: 10px 20px;
                        border-radius: 8px;
                        color: #ffffff;
                        transition: background 0.3s ease;
                    }

                    .movie-card:hover .movie-title {
                        background: rgba(26, 42, 68, 1);
                    }

                    .movie-list::-webkit-scrollbar {
                        height: 10px;
                    }

                    .movie-list::-webkit-scrollbar-track {
                        background: #0D0D0D;
                    }

                    .movie-list::-webkit-scrollbar-thumb {
                        background: #2A3B5A;
                        border-radius: 10px;
                    }

                    .movie-list::-webkit-scrollbar-thumb:hover {
                        background: #B0B7C0;
                    }

                    .footer {
                        width: 100vw; /* عرض کامل صفحه */
                        padding: 40px 60px;
                        background: #1A2A44;
                        text-align: center;
                        color: #B0B7C0;
                        font-size: 14px;
                        margin: 0; /* حذف margin */
                    }

                    .footer a {
                        color: #ffffff;
                        text-decoration: none;
                        margin: 0 10px;
                        transition: color 0.3s ease;
                    }

                    .footer a:hover {
                        color: #B0B7C0;
                    }
                `}</style>

                <header className="header">
                    <div className="logo">StreamFlix</div>
                    <nav className="nav">
                        <Link to="/">Home</Link>
                        <Link to="/tv-shows">TV Shows</Link>
                        <Link to="/movies">Movies</Link>
                        <Link to="/my-list">My List</Link>
                    </nav>
                    <input
                        type="text"
                        placeholder="Search..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="search-bar"
                    />
                </header>

                <Routes>
                    <Route
                        path="/"
                        element={
                            <>
                                {loading ? (
                                    <div className="loading">Loading...</div>
                                ) : error ? (
                                    <div className="error">{error}</div>
                                ) : (
                                    <>
                                        {featuredMovie && (
                                            <section className="hero" style={{ backgroundImage: `url(${featuredMovie.thumbnail || 'https://picsum.photos/1200/600?random=1'})` }}>
                                                <div className="hero-content">
                                                    <h1>{featuredMovie.title}</h1>
                                                    <p>{featuredMovie.description}</p>
                                                    <div className="hero-buttons">
                                                        <Link to={`/movie/${featuredMovie.id}`}>
                                                            <button className="play-btn">
                                                                <span className="play-icon">▶</span> Play
                                                            </button>
                                                        </Link>
                                                        <Link to={`/movie/${featuredMovie.id}`}>
                                                            <button className="info-btn">
                                                                <span className="info-icon">ℹ</span> More Info
                                                            </button>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </section>
                                        )}

                                        <main className="content">
                                            {Object.entries(movieCategories).map(([category, movies]) => (
                                                movies.length > 0 && (
                                                    <div key={category} className="category-section">
                                                        <h2>{category}</h2>
                                                        <div className="movie-list">
                                                            {movies.map((movie) => (
                                                                <Link to={`/movie/${movie.id}`} key={movie.id}>
                                                                    <div className="movie-card">
                                                                        <img src={movie.thumbnail || 'https://picsum.photos/300/169?random=2'} alt={movie.title} />
                                                                        <div className="movie-title">{movie.title}</div>
                                                                    </div>
                                                                </Link>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )
                                            ))}
                                        </main>

                                        <footer className="footer">
                                            <p>© 2025 StreamFlix. All rights reserved.</p>
                                            <p>
                                                <a href="#">About</a> | <a href="#">Contact</a> | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
                                            </p>
                                        </footer>
                                    </>
                                )}
                            </>
                        }
                    />
                    <Route path="/movie/:id" element={<MovieDetail />} />
                    <Route path="/tv-shows" element={<div className="loading">TV Shows Page (Coming Soon)</div>} />
                    <Route path="/movies" element={<div className="loading">Movies Page (Coming Soon)</div>} />
                    <Route path="/my-list" element={<div className="loading">My List Page (Coming Soon)</div>} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;