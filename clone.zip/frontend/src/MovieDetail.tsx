// frontend/src/MovieDetail.tsx
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

interface Genre {
    id: number;
    name: string;
}

interface Movie {
    id: number;
    title: string;
    description: string;
    release_date: string;
    genres: Genre[];
    created_at: string;
    thumbnail?: string | null;
}

const MovieDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [movie, setMovie] = useState<Movie | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchMovie = async () => {
            try {
                setLoading(true);
                setError(null);
                const response = await fetch(`http://localhost:8000/api/posts/movies/${id}/`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
                if (!response.ok) throw new Error(`Failed to fetch movie: ${response.statusText}`);
                const data: Movie = await response.json();
                setMovie(data);
            } catch (error: any) {
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchMovie();
    }, [id]);

    if (loading) {
        return <div className="loading">Loading...</div>;
    }

    if (error) {
        return <div className="error">{error}</div>;
    }

    if (!movie) {
        return <div className="error">Movie not found.</div>;
    }

    return (
        <div className="movie-detail">
            <style>{`
                .movie-detail {
                    min-height: 100vh;
                    background-color: #0D0D0D;
                    color: #B0B7C0;
                    padding: 100px 40px;
                }

                .back-btn {
                    display: inline-block;
                    margin-bottom: 20px;
                    color: #B0B7C0;
                    text-decoration: none;
                    font-size: 16px;
                    font-weight: 500;
                    transition: color 0.3s ease;
                }

                .back-btn:hover {
                    color: #ffffff;
                }

                .movie-detail-content {
                    display: flex;
                    gap: 40px;
                    align-items: flex-start;
                }

                .movie-detail-image {
                    flex: 0 0 400px;
                }

                .movie-detail-image img {
                    width: 100%;
                    border-radius: 12px;
                    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4);
                    transition: transform 0.3s ease;
                }

                .movie-detail-image img:hover {
                    transform: scale(1.02);
                }

                .movie-detail-info {
                    flex: 1;
                }

                .movie-detail-info h1 {
                    font-size: 48px;
                    font-weight: 700;
                    color: #ffffff;
                    margin-bottom: 20px;
                }

                .movie-detail-info p {
                    font-size: 18px;
                    font-weight: 300;
                    line-height: 1.8;
                    margin-bottom: 20px;
                }

                .movie-detail-info .genres {
                    margin-bottom: 20px;
                }

                .movie-detail-info .genres span {
                    background: #2A3B5A;
                    padding: 5px 15px;
                    border-radius: 15px;
                    margin-right: 10px;
                    font-size: 14px;
                    font-weight: 500;
                }

                .movie-detail-buttons {
                    display: flex;
                    gap: 20px;
                }

                .movie-detail-buttons button {
                    padding: 14px 35px;
                    border: none;
                    border-radius: 30px;
                    font-size: 16px;
                    font-weight: 500;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    transition: transform 0.2s ease, box-shadow 0.3s ease, background 0.3s ease;
                }

                .movie-detail-buttons button:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5);
                }

                .play-btn {
                    background: #B0B7C0;
                    color: #0D0D0D;
                }

                .play-btn:hover {
                    background: #ffffff;
                }

                .info-btn {
                    background: #2A3B5A;
                    color: #B0B7C0;
                }

                .info-btn:hover {
                    background: #3A4B7A;
                }

                .play-icon, .info-icon {
                    font-size: 20px;
                }
            `}</style>

            <Link to="/" className="back-btn">← Back to Home</Link>
            <div className="movie-detail-content">
                <div className="movie-detail-image">
                    <img src={movie.thumbnail || 'https://picsum.photos/400/600?random=1'} alt={movie.title} />
                </div>
                <div className="movie-detail-info">
                    <h1>{movie.title}</h1>
                    <p><strong>Release Date:</strong> {movie.release_date}</p>
                    <p>{movie.description}</p>
                    <div className="genres">
                        <strong>Genres:</strong>{' '}
                        {movie.genres.map(genre => (
                            <span key={genre.id}>{genre.name}</span>
                        ))}
                    </div>
                    <div className="movie-detail-buttons">
                        <button className="play-btn">
                            <span className="play-icon">▶</span> Play
                        </button>
                        <button className="info-btn">
                            <span className="info-icon">ℹ</span> More Info
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MovieDetail;