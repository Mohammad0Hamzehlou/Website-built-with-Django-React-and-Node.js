from django.urls import path, include
from rest_framework.routers import DefaultRouter
from posts.api.views import PostViewSet, GenreViewSet, MovieViewSet, MovieReviewsView, CreateReviewView

# 📌 ایجاد Router برای ViewSet ها
router = DefaultRouter()
router.register(r'posts', PostViewSet, basename='post')
router.register(r'genres', GenreViewSet, basename='genre')
router.register(r'movies', MovieViewSet, basename='movie')

urlpatterns = [
    path('', include(router.urls)),  # مسیرهای خودکار برای ViewSetها
    path('movies/<int:movie_id>/reviews/', MovieReviewsView.as_view(), name='movie-reviews'),  # دریافت نظرات فیلم
    path('reviews/create/', CreateReviewView.as_view(), name='create-review'),  # ایجاد نظر جدید
]
