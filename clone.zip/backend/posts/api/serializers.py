# posts/api/serializers.py
from rest_framework import serializers
from posts.models import Post, Genre, Movie, Review  # مدل‌ها رو از models.py وارد می‌کنیم

class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = '__all__'

class GenreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Genre
        fields = '__all__'

class MovieSerializer(serializers.ModelSerializer):
    genres = GenreSerializer(many=True, read_only=True)  # نمایش اطلاعات کامل ژانرها
    genre_ids = serializers.PrimaryKeyRelatedField(
        queryset=Genre.objects.all(), many=True, write_only=True, source='genres'
    )
    thumbnail = serializers.ImageField(required=False, allow_null=True)  # فیلد thumbnail که قبلاً اضافه کردیم

    class Meta:
        model = Movie
        fields = ['id', 'title', 'description', 'release_date', 'genres', 'genre_ids', 'created_at', 'thumbnail']

class ReviewSerializer(serializers.ModelSerializer):
    movie = serializers.StringRelatedField()  # نمایش عنوان فیلم به جای ID
    movie_id = serializers.PrimaryKeyRelatedField(
        queryset=Movie.objects.all(), write_only=True, source='movie'
    )

    class Meta:
        model = Review
        fields = ['id', 'movie', 'movie_id', 'author', 'content', 'rating', 'created_at']