from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.views import APIView
from posts.models import Post, Genre, Movie, Review
from .serializers import PostSerializer, GenreSerializer, MovieSerializer, ReviewSerializer


# 📌 مدیریت پست‌ها (CRUD)
class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer


# 📌 مدیریت ژانرها (CRUD)
class GenreViewSet(viewsets.ModelViewSet):
    queryset = Genre.objects.all()
    serializer_class = GenreSerializer


# 📌 مدیریت فیلم‌ها (CRUD)
class MovieViewSet(viewsets.ModelViewSet):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer


# 📌 نمایش نظرات مربوط به یک فیلم خاص
class MovieReviewsView(APIView):
    def get(self, request, movie_id):
        try:
            reviews = Review.objects.filter(movie_id=movie_id)
            serializer = ReviewSerializer(reviews, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Movie.DoesNotExist:
            return Response({"error": "Movie not found"}, status=status.HTTP_404_NOT_FOUND)


# 📌 ثبت نظر برای یک فیلم
class CreateReviewView(APIView):
    def post(self, request):
        serializer = ReviewSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
