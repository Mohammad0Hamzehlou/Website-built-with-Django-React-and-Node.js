# backend/posts/admin.py
from django.contrib import admin
from .models import Post, Genre, Movie, Review

# ثبت مدل‌ها در پنل ادمین
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at')
    search_fields = ('title', 'content')

@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ('title', 'release_date', 'created_at')
    search_fields = ('title', 'description')
    list_filter = ('genres', 'release_date')

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('movie', 'author', 'rating', 'created_at')
    search_fields = ('author', 'content')
    list_filter = ('rating', 'created_at')